// Initialize Leaflet map
var parisCoordinates = [48.8566, 2.3522];
var map = L.map('map').setView(parisCoordinates, 11);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Variable pour stocker les marqueurs et les tags correspondants
var markers = {};

// Chargement des données GeoJSON
fetch('routes.geojson')
  .then(response => response.json())
  .then(data => {
    L.geoJSON(data, {
      style: {
        color: 'blue',
        weight: 1.5,
        opacity: 0.7
      }
    }).addTo(map);

    data.features.forEach(feature => {
      var coordinates = feature.geometry.coordinates;
      var properties = feature.properties;

      var startMarker = L.marker([coordinates[0][1], coordinates[0][0]])
        .bindPopup(`<b>${properties.libelle}</b><br>${properties.code_ligne}`)
        .addTo(map);

      var endMarker = L.marker([coordinates[coordinates.length - 1][1], coordinates[coordinates.length - 1][0]])
        .bindPopup(`<b>${properties.libelle}</b><br>${properties.code_ligne}`)
        .addTo(map);

      // Sauvegarde des marqueurs dans la variable markers avec l'identifiant unique
      markers[properties.id] = { start: startMarker, end: endMarker };
    });
  })
  .catch(error => {
    console.error('Error fetching GeoJSON:', error);
    alert('Error fetching GeoJSON. Please try again.');
  });

// Gestionnaire d'événement pour ajouter des tags sur un clic de carte
map.on('click', function(event) {
  const { lat, lng } = event.latlng;
  const info = prompt('Enter information for this location:');
  if (info) {
    const tag = { x: lat, y: lng, info };
    saveTag(tag);
  }
});

// Fonction pour sauvegarder les tags sur le serveur
function saveTag(tag) {
  fetch('/tags', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(tag)
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Failed to save tag');
    }
    return response.json();
  })
  .then(savedTag => {
    addMarker(savedTag);
  })
  .catch(error => {
    console.error(error);
    alert('Failed to save tag');
  });
}

// Fonction pour ajouter un marqueur à la carte
function addMarker(tag) {
  const { x, y, id } = tag;
  const marker = L.marker([x, y]).addTo(map).bindPopup(tag.info);
  
  // Enregistrement du marqueur dans la variable markers avec l'identifiant du tag
  markers[id] = marker;
}

// Fonction pour mettre à jour la position d'un marqueur
function updateMarkerPosition(tag) {
  const { x, y, id } = tag;
  const marker = markers[id];
  if (marker) {
    marker.setLatLng([x, y]);
  }
}

// Gestionnaire d'événement pour mettre à jour les positions des marqueurs lors du déplacement de la carte
map.on('moveend', function() {
  fetch('/tags')
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to fetch tags');
      }
      return response.json();
    })
    .then(tags => {
      tags.forEach(tag => updateMarkerPosition(tag));
    })
    .catch(error => {
      console.error(error);
      alert('Failed to fetch tags');
    });
});
