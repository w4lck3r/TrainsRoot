const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');




const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('frontend'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/frontend/index.html');
});

// Endpoint to handle storing tag information
app.post('/tags', (req, res) => {
  const { x, y, info } = req.body;
  const tags = JSON.parse(fs.readFileSync('frontend/data.json')); // Assuming data is stored in a JSON file
  tags.push({ x, y, info });
  fs.writeFileSync('data.json', JSON.stringify(tags));
  res.sendStatus(200);
});

// Endpoint to handle retrieving tag information
app.get('/tags', (req, res) => {
  const tags = JSON.parse(fs.readFileSync('data.json')); // Assuming data is stored in a JSON file
  res.json(tags);
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
